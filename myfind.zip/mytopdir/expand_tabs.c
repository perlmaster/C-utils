/*********************************************************************
*
* File      : expand_tabs.c
*
* Author    : Barry Kimelman
*
* Created   : August 29, 2001
*
* Purpose   : Expand tabs to spaces.
*
*********************************************************************/

#include	<stdio.h>
#include	<string.h>

/*********************************************************************
*
* Function  : expand_tabs
*
* Purpose   : Expand tabs to spaces.
*
* Inputs    : char *new_buffer - buffer to receive expanded data
*             char *old_buffer - buffer with original data
*             int tabstop - tabstop width
*
* Output    : (none)
*
* Returns   : zero
*
* Example   : expand_tabs(new,old,8);
*
* Notes     : (none)
*
*********************************************************************/

int expand_tabs(char *new_buffer, char *old_buffer, int tabstop)
{
	int		count , old_length , new_length;
	char	*new_ptr , *old_ptr , ch;

	old_length = strlen(old_buffer);
	new_length = 0;
	new_ptr = new_buffer;
	*new_ptr = '\0';
	old_ptr = old_buffer;
	for ( count = 0 ; count < old_length ; ++count , ++old_ptr ) {
		ch = *old_ptr;
		if ( ch != '\t' ) {
			*new_ptr = ch;
			new_ptr += 1;
			*new_ptr = '\0';
			new_length += 1;
		} /* IF */
		else {
			new_length = ( (new_length + tabstop) / tabstop ) * tabstop;
			sprintf(new_buffer,"%-*.*s",new_length,new_length,new_buffer);
			new_ptr = &new_buffer[new_length];
		} /* ELSE */
	} /* FOR */
	*new_ptr = '\0';
	return(0);
} /* end of expand_tabs */
