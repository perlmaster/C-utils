/*********************************************************************
*
* File      : quit.c
*
* Author    : Barry Kimelman
*
* Created   : August 29, 2001
*
* Purpose   : Terminate program execution with a system failure message.
*
*********************************************************************/

#include	<stdio.h>
#include	<stdarg.h>
#include	<errno.h>

/*********************************************************************
*
* Function  : quit
*
* Purpose   : Terminate program execution with a system failure message.
*
* Inputs    : int exit_code - exit status
*             variable argument list (ala printf)
*
* Output    : (none)
*
* Returns   : (nothing)
*
* Example   : quit(1,"Can't open file %s",filename);
*
* Notes     : (none)
*
*********************************************************************/

void quit(int exit_code,char *format,...)
{
	va_list	ap;
	int		errnum;

	errnum = errno;
	va_start(ap,format);
	vfprintf(stderr,format,ap);
	va_end(ap);
    fprintf(stderr," : %s\n",strerror(errnum));
    fflush(stderr);
	errno = errnum;
	exit(exit_code);
} /* end of quit */
