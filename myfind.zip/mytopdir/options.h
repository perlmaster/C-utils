#ifndef OPTIONS_H_INCL
#define	OPTIONS_H_INCL	1

#include	<regex.h>

#define	OPT_NAME		0
#define	OPT_PERM		1
#define	OPT_TYPE		2
#define	OPT_LINKS		3
#define	OPT_USER		4
#define	OPT_GROUP		5
#define	OPT_BLOCKS		6
#define	OPT_BYTES		7
#define	OPT_ATIME		8
#define	OPT_MTIME		9
#define	OPT_CTIME		10
#define	OPT_NEWER		11
#define	OPT_PRINT		12
#define	OPT_DELETE		13
#define	OPT_LS			14
#define	OPT_KILL		15
#define	OPT_FILE		16
#define	OPT_EXEC		17
#define	OPT_GREP		18
#define	OPT_WC			19
#define	OPT_LEVELS		20
#define	OPT_LSO			21
#define	OPT_NOTUSER		22
#define	OPT_MYFILE		23
#define	OPT_IGREP		24
#define	OPT_MINSIZE		25
#define	OPT_MAXSIZE		26
#define	OPT_LIST4		27
#define	OPT_LIST8		28
#define	OPT_LGREP		29
#define	OPT_SYMLINK		30
#define	OPT_READONLY	31
#define	OPT_NOTMYFILE	32
#define	OPT_LSI			33
#define	OPT_FILE_PMASK	34
#define	OPT_TODAY		35
#define	OPT_ADDPERM		36
#define	OPT_DELPERM		37
#define	OPT_CHMOD		38
#define	OPT_TOUCH		39
#define	OPT_INAME		40
#define	OPT_TAR			41
#define	OPT_VI			42
#define	OPT_MODE		43
#define	OPT_DEBUG		44
#define	OPT_CAT			45
#define	OPT_NUM			46
#define	OPT_YESTERDAY	47
#define	OPT_NOERR		48
#define	OPT_HELP		49
#define	OPT_SKIPDIR		50
#define	OPT_RUN			51
#define	OPT_NOTPERMMASK	52
#define	OPT_HGREP		53
#define	OPT_HEAD		54
#define	OPT_DOUBLE		55
#define	OPT_COPY		56
#define	OPT_INUM		57
#define	OPT_FILETYPE	58
#define	OPT_EXCLUDE		59

#define	MAX_NUM_OPTIONS		100

typedef	struct option_tag {
	int		option_code;
	char	*opt_string;
	int		opt_number;
	int		modifier;
	regex_t	expression;
} OPTION ;

typedef	struct {
	char	*opt_name;
	char	*description;
	int		(*opt_function)();
} OPTION_FUNCTION;

#endif
