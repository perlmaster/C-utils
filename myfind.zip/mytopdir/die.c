/*********************************************************************
*
* File      : die.c
*
* Author    : Barry Kimelman
*
* Created   : August 29, 2001
*
* Purpose   : Display an error emssage and terminate execution.
*
*********************************************************************/

#include	<stdio.h>
#include	<stdarg.h>

/*********************************************************************
*
* Function  : die
*
* Purpose   : Display a formatted message and then terminate
*             program execution.
*
* Inputs    : int exit_code - exit status
*             variable argument list (ala printf)
*
* Output    : the formatted message
*
* Returns   : requested exit status
*
* Example   : die(1,"Missing parameters.\n");
*
* Notes     : (none)
*
*********************************************************************/

void die(int exit_code,char *format,...)
{
	va_list	ap;

	va_start(ap,format);
	vfprintf(stderr,format,ap);
	va_end(ap);
	exit(exit_code);
} /* end of die */
