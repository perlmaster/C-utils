/*********************************************************************
*
* File      : list_file_attr.c
*
* Author    : Barry Kimelman
*
* Created   : August 29, 2001
*
* Purpose   : List file attributes (similar to ls).
*
*********************************************************************/

#include	<stdio.h>
#include	<sys/types.h>
#include	<sys/stat.h>
#include	<dirent.h>
#include	<string.h>
#include	<malloc.h>
/* #include	<libgen.h> COMMENTED OUT FOR DOS */
#include	<pwd.h>
#include	<grp.h>
#include	<time.h>
#include	<unistd.h>

extern	void	bad_syscall();

/*********************************************************************
*
* Function  : process_permission_bits
*
* Purpose   : Process one of the 3 groups of permission bits.
*
* Inputs    : char grouping - indicates which group of bits to process
*             struct stat *stats_ptr - ptr to stat structure
*             char *bits_buffer - buffer to receive bits information
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : process_permission_bits('o',stats_ptr,owner_bits);
*
* Notes     : (none)
*
*********************************************************************/

static int process_permission_bits(grouping,stats_ptr,bits_buffer)
char grouping; struct stat *stats_ptr; char *bits_buffer;
{
	mode_t	permission_bits;
	mode_t	rwx;
	static char	*perms_list[8] = { "---" , "--x" , "-w-" , "-wx" ,
									"r--" , "r-x" , "rw-" , "rwx" };
	char	*perms;

	strcpy(bits_buffer,"---");
	permission_bits = stats_ptr->st_mode & 0777;
	switch (grouping) {
	case 'o':
		rwx = (permission_bits & 0700) >> 6;
		break;
	case 'g':
		rwx = (permission_bits & 0070) >> 3;
		break;
	case 'w':
		rwx = permission_bits & 0007;
		break;
	} /* SWITCH */
	strcpy(bits_buffer,perms_list[rwx]);

	return(1);
} /* end of process_permission_bits */

/*********************************************************************
*
* Function  : list_file_attr
*
* Purpose   : List file attributes (similar to ls).
*
* Inputs    : char *filename - name of file
*             struct stat *stats_ptr - ptr to stat structure
*             int group_flag - flag indicating if group is to be displayed
*             int inode_flag - flag indicating if inode is to be displayed
*             int dir_flag - flag indicating if ??? is to be displayed
*
* Output    : (none)
*
* Returns   : (nothing)
*
* Example   : list_file_attr(filename,&filestats,0,0,0,0,1);
*
* Notes     : (none)
*
*********************************************************************/

int list_file_attr(char *filename, struct stat *stats_ptr, int group_flag,
int inode_flag, int dir_flag)
{
	struct stat		filestats;
	mode_t	permission_bits;
	ushort	filemode;
	char	filetype , owner_bits[16] , group_bits[16] , world_bits[16];
	char	username[128] , groupname[128] , file_date[80];
	char	real_path[256] , *path_ptr , trailing_char;
	struct passwd	*user_defn;
	struct group	*group_defn;
	static char	*months[12] = { "Jan" , "Feb" , "Mar" , "Apr" , "May" , "Jun" ,
						"Jul" , "Aug" , "Sep" , "Oct" , "Nov" , "Dec" } ;
	struct tm	*filetime;

	if ( stats_ptr == NULL ) {
		if ( lstat(filename,&filestats) < 0 ) {
			bad_syscall("stat failed for \"%s\"",filename);
			return(1);
		} /* IF */
		stats_ptr = &filestats;
	} /* IF */

	filemode = stats_ptr->st_mode & S_IFMT;
	switch(filemode) {
	case S_IFDIR:
		filetype = 'd';
		trailing_char = '/';
		break;
	case S_IFREG:
		filetype = '-';
		trailing_char = ' ';
		break;
	case S_IFBLK:
		filetype = 'b';
		trailing_char = ' ';
		break;
	case S_IFCHR:
		filetype = 'c';
		trailing_char = ' ';
		break;
	case S_IFIFO:
		filetype = 'p';
		trailing_char = '|';
		break;
	case S_IFSOCK:
		filetype = 's';
		trailing_char = '=';
		break;
	case S_IFLNK:
		filetype = 'l';
		trailing_char = '@';
		break;
	default:
		filetype = '?';
		trailing_char = ' ';
	} /* SWITCH over file type */
	permission_bits = stats_ptr->st_mode & 07777;
	debug_print("Perms for %s are 0%o\n",filename,permission_bits);
	process_permission_bits('o',stats_ptr,owner_bits);
	if ( permission_bits & S_ISUID ) {
		debug_print("SUID on for %s\n",filename);
		if ( permission_bits & S_IXUSR )
			owner_bits[2] = 's';
		else
			owner_bits[2] = 'S';
	} /* IF set userid on exec */
	process_permission_bits('g',stats_ptr,group_bits);
	if ( permission_bits & S_ISGID ) {
		if ( permission_bits & S_IXGRP )
			group_bits[2] = 's';
		else
			group_bits[2] = 'S';
	} /* IF set groupid on exec */
	process_permission_bits('w',stats_ptr,world_bits);
	if ( permission_bits & S_ISVTX ) {
		if ( access(filename,X_OK) == 0 )
			world_bits[2] = 't';
		else
			world_bits[2] = 'T';
	} /* IF sticky bit on */

	setpwent();	/* open the password file */
	user_defn = getpwuid(stats_ptr->st_uid);
	if ( user_defn != NULL )
		strcpy(username,user_defn->pw_name);
	else
		strcpy(username,"???");
	endpwent();	/* close the password file */

	if ( group_flag ) {
		setgrent();	/* open the groups file */
		group_defn = getgrgid(stats_ptr->st_gid);
		if ( group_defn != NULL )
			strcpy(groupname,group_defn->gr_name);
		else
			strcpy(groupname,"???");
	endgrent();	/* close the groups file */
	} /* IF */
	filetime = localtime(&stats_ptr->st_mtime);
	sprintf(file_date,"%3.3s %2d, %d %02d:%02d:%02d",months[filetime->tm_mon],
			filetime->tm_mday,1900+filetime->tm_year,filetime->tm_hour,filetime->tm_min,
			filetime->tm_sec);
	if ( inode_flag ) {
		printf("%6d ",stats_ptr->st_ino);
	} /* IF */
	printf("%c%s%s%s %3d %-8s",
			filetype,owner_bits,group_bits,world_bits,
			stats_ptr->st_nlink,username);
	if ( group_flag ) {
		printf(" %-8s",groupname);
	} /* IF */
	path_ptr = (filename[0] == '.' && filename[1] == '/') ? &filename[2] : filename;
	printf(" %11ld %s %s",stats_ptr->st_size,file_date,path_ptr);
	if ( filetype == 'l' ) {
		printf(" -> ");
		memset(real_path , 0 , sizeof(real_path));
		if ( readlink(filename,real_path,sizeof(real_path)) < 0 ) {
			printf("(??)");
		} /* IF */
		else {
			printf("%s",real_path);
		} /* ELSE */
	} /* IF */
	printf("\n");

	return(0);
} /* end of list_file_attr */
