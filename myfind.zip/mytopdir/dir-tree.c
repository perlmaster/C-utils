/*********************************************************************
*
* File      : dir-tree.c
*
* Author    : Barry Kimelman
*
* Created   : August 29, 2001
*
* Purpose   : Recursively process a directory tree.
*
*********************************************************************/

#include	<stdio.h>
#include	<stdlib.h>
#include	<sys/types.h>
#include	<sys/stat.h>
#include	<dirent.h>
#include	<malloc.h>
#include	<string.h>
#include	<regex.h>
#include	"macros.h"

#define	MAX_SUBDIRS	4096	/* max num of subdirs at one level */

struct stat	entry_stats , symlink_entry_stats;
char	entry_name[BUFSIZ+1];
char	entry_pathname[BUFSIZ+1] , entry_resolved_linkpath[1024];
char	entry_filetype , symlink_entry_filetype;

extern	int		dir_level , max_dir_level , follow_dir_symlink;
extern	char	skip_dir_pattern[];
extern	regex_t	skip_dir_expression;

extern	int		process_options();
extern	void	bad_syscall() , debug_print();

/*********************************************************************
*
* Function  : process_dir_tree
*
* Purpose   : Recursively process a directory tree.
*
* Inputs    : char *dirname - name of directory
*
* Output    : (none)
*
* Returns   : If ok Then zero Else -1
*
* Example   : process_dir_tree(dirname);
*
* Notes     : (none)
*
*********************************************************************/

int process_dir_tree(char *dirname)
{
	DIR		*dirp;
	struct dirent	*dir_entry;
	int		num_entries , num_subdirs , status , count , errcode;
	ushort	filemode , symlink_filemode;
	char	*subdir_list[MAX_SUBDIRS];
	regmatch_t	pmatch[2];

	debug_print("\nprocess_dir_tree(\"%s\") entered.\n",dirname);
	dirp = opendir(dirname);
	if ( dirp == NULL ) {
		bad_syscall("opendir failed for \"%s\"",dirname);
		return(-1);
	} /* IF */

	num_entries = 0;
	num_subdirs = 0;
	while ( (dir_entry = readdir(dirp)) != NULL ) {
		num_entries += 1;
		strcpy(entry_name,dir_entry->d_name);
		sprintf(entry_pathname,"%s/%s",dirname,entry_name);
		if ( lstat(entry_pathname,&entry_stats) < 0 ) {
			bad_syscall("lstat failed for \"%s\"",entry_pathname);
			continue;
		} /* IF */
		filemode = entry_stats.st_mode & S_IFMT;
		symlink_entry_filetype = ' ';
		switch(filemode) {
		case S_IFDIR:
			entry_filetype = 'd';
			break;
		case S_IFREG:
			entry_filetype = 'f';
			break;
		case S_IFBLK:
			entry_filetype = 'b';
			break;
		case S_IFCHR:
			entry_filetype = 'c';
			break;
		case S_IFIFO:
			entry_filetype = 'p';
			break;
		case S_IFSOCK:
			entry_filetype = 's';
			break;
		case S_IFLNK:
			entry_filetype = 'l';
			memset(entry_resolved_linkpath , 0 , sizeof(entry_resolved_linkpath));
			if ( readlink(entry_pathname,entry_resolved_linkpath,sizeof(entry_resolved_linkpath)) <= 0 ) {
				bad_syscall("readlink failed for \"%s\"",entry_pathname);
			} /* IF */
			if ( stat(entry_pathname,&symlink_entry_stats) < 0 ) {
				bad_syscall("stat failed for \"%s\"",entry_pathname);
				symlink_entry_stats.st_size = -1;
			} /* IF */
			else {
				symlink_filemode = symlink_entry_stats.st_mode & S_IFMT;
				if ( symlink_filemode == S_IFDIR ) {
					symlink_entry_filetype = 'd';
				} /* IF */
			} /* ELSE */
			break;
		default:
			entry_filetype = '?';
		} /* SWITCH over file type */
		if ( entry_filetype == 'd' || (follow_dir_symlink && symlink_entry_filetype == 'd') ) {
			if ( NE(".",entry_name) && NE(entry_name,"..") ) {

				if ( skip_dir_pattern[0] == '\0' || 
						regexec(&skip_dir_expression, entry_name,(size_t)1, pmatch, 0)
									!= 0 ) {
					if ( num_subdirs >= MAX_SUBDIRS ) {
						die(1,"subdir limit of %d exceeded under \"%s\"\n",MAX_SUBDIRS,dirname);
					} /* IF */
					subdir_list[num_subdirs] = strdup(entry_pathname);
					if ( subdir_list[num_subdirs] == NULL ) {
						quit(1,"strdup failed for subdir_list");
					} /* IF malloc for strdup failed */
					num_subdirs += 1;
				} /* IF dir is not to be ignored */
				else {
					debug_print("Skip over directory \"%s\"\n",entry_pathname);
				} /* ELSE */
			} /* IF not current or parent directory */
		} /* IF a directory */
		if ( NE(".",entry_name) && NE(entry_name,"..") ) {
			process_options();
		} /* IF */
	} /* WHILE over directory entries */
	closedir(dirp);
	for ( count = 0 ; count < num_subdirs ; ++count ) {
		dir_level += 1;
		if ( max_dir_level < 0 || dir_level <= max_dir_level ) {
			status = process_dir_tree(subdir_list[count]);
		} /* IF */
		dir_level -= 1;
		free(subdir_list[count]);
	} /* FOR */

	return(status);
} /* end of process_dir_tree */
