/*********************************************************************
*
* File      : isdir.c
*
* Author    : Barry Kimelman
*
* Created   : September 23, 2008
*
* Purpose   : Test to see if a string represents a directory.
*
* Notes     : (none)
*
*********************************************************************/

#include	<stdio.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/stat.h>

/*********************************************************************
*
* Function  : isdir
*
* Purpose   : Test to see if a path represents an existing directory.
*
* Inputs    : char *path - the path to be tested
*
* Output    : appropriate diagnostics
*
* Returns   : If path represents a directory Then 1 Else 0
*
* Example   : flag = isdir(path);
*
* Notes     : (none)
*
*********************************************************************/

int isdir(char *path)
{
	struct stat		pathstats;
	int		status;

	status = stat(path,&pathstats) == 0 && (pathstats.st_mode & S_IFMT)  == S_IFDIR;

	return status;
} /* end of isdir */
