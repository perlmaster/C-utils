/*********************************************************************
*
* File      : main.c
*
* Author    : Barry Kimelman
*
* Created   : August 29, 2001
*
* Purpose   : Main module for program.
*
*********************************************************************/

#include	<sys/types.h>
#include	<sys/stat.h>
#include	<dirent.h>
#include	<stdio.h>
#include	<unistd.h>
#include	<malloc.h>
#include	<strings.h>
#include	<libgen.h>
#include	<time.h>
#include	<signal.h>
#include	<stdarg.h>
#include	<regex.h>

char	*starting_dir = NULL;
int		dir_level = 0;
int		max_dir_level = -1;
int		verbose_mode = 0;
int		debug_mode = 0;
int		double_spacing = 0;
int		no_errors = 0;
char	*progname = NULL;
time_t	starting_time;
int		follow_dir_symlink = 0;
int		my_uid = -1;
int		day_seconds;
int		help_only = 0;
char	skip_dir_pattern[256];
regex_t	skip_dir_expression;

extern	int	process_dir_tree();

extern	int		parse_options();
extern	int		init_termcap();
extern	void	die();

/*********************************************************************
*
* Function  : debug_print
*
* Purpose   : Optionally print a debugging message.
*
* Inputs    : va_alist - arguments comprising message
*
* Output    : (none)
*
* Returns   : (nothing)
*
* Example   : debug_print("Process the file %s\n",filename);
*
* Notes     : (none)
*
*********************************************************************/

void debug_print(char *fmt, ...)
{
     va_list ap;

	 if ( debug_mode ) {
		va_start(ap, fmt);
		vprintf(fmt,ap);
		va_end(ap);
	}
	return;
} /* end of debug_print */

/*********************************************************************
*
* Function  : mysig
*
* Purpose   : signal handler
*
* Inputs    : int signum - signal number
*
* Output    : appropriate error emssage
*
* Returns   : signal number
*
* Example   : (none)
*
* Notes     : This handler is meant to be called by UNIX.
*
*********************************************************************/

void mysig(int signum)
{
	fflush(stdout);
	fflush(stderr);
	die(signum,"%s : Signal %d received\n",progname,signum);
} /* end of mysig */

/*********************************************************************
*
* Function  : main
*
* Purpose   : program entry point
*
* Inputs    : int argc
*             char *argv[]
*
* Output    : requested output
*
* Returns   : If ok Then zero Else appropriate code
*
* Example   : find2 . -print
*
* Notes     : (none)
*
*********************************************************************/

int main(int argc, char *argv[])
{
	int		status;

	progname = argv[0];
	signal(SIGTERM,mysig);
	signal(SIGSEGV,mysig);
	signal(SIGBUS,mysig);
	init_termcap(stderr);

	starting_time = time(NULL);
	my_uid = getuid();
	day_seconds = 24 * 60 * 60; /* number of seconds in 1 day */
	skip_dir_pattern[0] = '\0';

	status = parse_options(argc,argv);
	if ( status )
		die(1,"Scanning aborted due to parsing error(s).\n");
	if ( ! help_only ) {
		status = process_dir_tree(starting_dir);
	} /* IF */
	exit(0);
} /* end of main */
