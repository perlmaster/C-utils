/*********************************************************************
*
* File      : options.c
*
* Author    : Barry Kimelman
*
* Created   : August 29, 2001
*
* Purpose   : Routines to process options.
*
*********************************************************************/

#include	<stdio.h>
#include	<sys/types.h>
#include	<sys/stat.h>
#include	<sys/time.h>
#include	<dirent.h>
#include	<string.h>
#include	<malloc.h>
#include	<pwd.h>
#include	<grp.h>
#include	<time.h>
#include	<utime.h>
#include	<unistd.h>
#include	<stdlib.h>
#include	<regex.h>
#include	"options.h"
#include	"macros.h"

#define	DAY_SECONDS		86400	/* no. of secs in 1 day */

typedef	struct {
	int	year;
	int	month;
	int	day;
} DATE_INFO;

int	num_options = 0;
OPTION	options_list[MAX_NUM_OPTIONS];
OPTION	*current_option;

int		check_file_name() , check_file_perms() , check_file_type();
int		check_file_links() ,check_file_owner() , check_file_group(); 
int		check_file_blocks() , check_file_bytes() , check_file_atime(); 
int		check_file_mtime() , check_file_ctime() , check_file_newer(); 
int		print_filename() , delete_file() , perform_ls() , kill_file();
int		perform_file() , perform_exec() , perform_grep() , perform_head();
int		perform_wc() , perform_lso() , check_file_not_owner() , check_myfile();
int		perform_igrep() , check_file_minsize() , check_file_maxsize();
int		list4_file() , list8_file() , list_file() , perform_lgrep();
int		check_read_only() , check_notmyfile() , perform_lsi();
int		check_file_perm_mask() , check_file_today() , add_file_perm_mask();
int		delete_file_perm_mask() , perform_chmod() , perform_touch();
int		perform_tar() , perform_vi() , perform_mode() , perform_cat();
int		perform_num() , check_file_yesterday() , perform_hgrep();
int		display_usage() , check_for_exec_perm() , check_file_not_perm_mask();
int		copy_file_under_dir() , check_inode_number() , display_filename_and_type();
int		perform_exclude();

/* The entries in the following table MUST be in order according to
   the option code (i.e. the option codes are used as indices into
   this list). The option codes are defined in options.h. */
OPTION_FUNCTION	option_functions[] = {
	{ "name" , "check name" , check_file_name } ,
	{ "perm" , "check for file permissions" , check_file_perms } ,
	{ "type" , "check file type" , check_file_type } ,
	{ "links" , "check number of links" , check_file_links },
	{ "user" , "check ownership" , check_file_owner } ,
	{ "group" , "check group" , check_file_group },
	{ "blocks" , "check number of 512 byte blocks" , check_file_blocks },
	{ "bytes" , "check file size" , check_file_bytes },
	{ "atime" , "check last-access time" , check_file_atime } ,
	{ "mtime" , "check last-modified time" , check_file_mtime } ,
	{ "ctime" , "check created time" , check_file_ctime } ,
	{ "newer" , "check for newer file" , check_file_newer } ,
	{ "print" , "display filename" , print_filename } ,
	{ "delete" , "delete file with verification" , delete_file } ,
	{ "ls" , "list file attributes" , perform_ls } ,
	{ "killfile" , "delete file without verification" , kill_file } ,
	{ "file" , "run 'file' command" , perform_file } ,
	{ "exec" , "run an external command" , perform_exec } ,
	{ "grep" , "case sensitive search" , perform_grep } ,
	{ "wc" , "count lines in file" , perform_wc } ,
	{ "levels" , "restrict levels of descent" , NULL } ,
	{ "lso" , "list file attributes excluding group membership" , perform_lso } ,
	{ "notuser" , "check file non-ownership" , check_file_not_owner } ,
	{ "myfile" , "check file for current user ownership" , check_myfile } ,
	{ "igrep" , "case insensitive search" , perform_igrep } ,
	{ "minsize" , "check for minimum filesize" , check_file_minsize } ,
	{ "maxsize" , "check for maximum filesize" , check_file_maxsize } ,
	{ "list4", "display file using tabwidth of 4" , list4_file } ,
	{ "list8", "display file using tabwidth of 8" , list8_file } ,
	{ "lgrep", "list filename matching pattern", perform_lgrep } ,
	{ "symlink" , "follow symbolic links" , NULL } ,
	{ "readonly" , "check for read-only file" , check_read_only } ,
	{ "notmyfile" , "check for non-ownership" , check_notmyfile } ,
	{ "lsi" , "list file attributes,  including inode-number" , perform_lsi } ,
	{ "permmask" , "check file permissions based on a mask" , check_file_perm_mask } ,
	{ "today" , "check for files modified today" , check_file_today } ,
	{ "addperm" , "turn on file permission bits" , add_file_perm_mask } ,
	{ "delperm" , "turn off file permission bits" , delete_file_perm_mask } ,
	{ "chmod" , "change permissions mode" , perform_chmod } ,
	{ "touch" , "change file access/modification time to current" , perform_touch } ,
	{ "iname" , "case-insensitive filename test" , check_file_name } ,
	{ "tar" , "add file to tar archive" , perform_tar } ,
	{ "vi" , "run vi on file" , perform_vi } ,
	{ "mode" , "display file's mode bits" , perform_mode } ,
	{ "debug" , "activate debugging mode" , NULL } ,
	{ "cat" , "display file contents" , perform_cat } ,
	{ "num" , "display file contents with line numbers" , perform_num } ,
	{ "yesterday" , "check for file modified yesterday" , check_file_yesterday } ,
	{ "noerr" , "turn off display of system error messages" , NULL } ,
	{ "help" , "display usage summary" , display_usage } ,
	{ "skipdir" , "skip directories with specific names" , NULL } ,
	{ "run" , "Check for perms to run a file" , check_for_exec_perm } ,
	{ "notpermmask" , "Check for absence of permissions" , check_file_not_perm_mask } ,
	{ "hgrep" , "grep with highlighting" , perform_hgrep } ,
	{ "head" , "display head of file" , perform_head } ,
	{ "double" , "activate double spacing" , NULL } ,
	{ "copy" , "copy file under directory" , copy_file_under_dir } ,
	{ "inum" , "check for a specific inode number" , check_inode_number } ,
	{ "filetype" , "display filename and file type" , display_filename_and_type } ,
	{ "exclude" , "exclude filename" , perform_exclude } ,
} ;
int	size_options_list = sizeof(option_functions) / sizeof(OPTION_FUNCTION);

char	*file_types = "fdcbpsDl";

DATE_INFO	yesterday;

extern	char	*starting_dir;
extern	int		dir_level;
extern	int		max_dir_level;
extern	int		verbose_mode;
extern	int		debug_mode;
extern	int		double_spacing;
extern	int		no_errors;
extern	int		follow_dir_symlink;
extern	int		my_uid;
extern	int		help_only;
extern	char	*progname;
extern	char	skip_dir_pattern[];
extern	regex_t	skip_dir_expression;
extern	int		tty_num_rows , tty_num_cols;

extern	struct stat	entry_stats;
extern	char	entry_name[];
extern	char	entry_pathname[] , entry_resolved_linkpath[];
extern	char	entry_filetype;
extern	time_t	starting_time;
extern	int		day_seconds;

int		get_userid();
int		get_group_id();
int		parse_numeric_option();
int		check_time();

OPTION	*save_numeric_option();
OPTION	*save_string_option();
OPTION	*save_pattern_option();
OPTION	*save_noparam_option();
OPTION	*save_filetime_option();

void	bad_option();
void	missing_option();
void	Usage();

extern	int		*search_strings_list() , expand_tabs();
extern	int		list_file_attr() , isdir();
extern	void	bad_syscall() , die();

/*********************************************************************
*
* Function  : parse_options
*
* Purpose   : Parse the options.
*
* Inputs    : int argc - number of options
*             char *argv[] - the options
*
* Output    : appropriate error messages
*
* Returns   : If ok Then zero Else appropriate code
*
* Example   : status = parse_options(argc,argv);
*
* Notes     : (none)
*
*********************************************************************/

int parse_options(int argc, char *argv[])
{
	char	*argptr , *option_name , *string;
	int		argnum , errors , number;
	int		opt_number , opt_index;
	OPTION	*option;
	time_t	clock;
	struct tm	*time_value;
	int		errcode;
	char	errmsg[256];

	argptr = argv[1];
	argnum = 1;
	if ( argnum >= argc || (*argptr == '-' && NE(argptr,"-help")) ) {
		printf("Missing directory name.\n");
		Usage();
		exit(1);
	} /* IF */
	if ( EQ(argptr,"-help") ) {
		display_usage();
		help_only = 1;
		return(0);
	} /* IF */
	starting_dir = argptr;
	argptr = argv[++argnum];
	if ( argc-argnum < 1 ) {
		Usage();
		exit(1);
	} /* IF */

	errors = 0;
	num_options = 0;
	for ( ; argnum < argc && *argptr == '-' ; argptr = argv[++argnum] ) {
		option_name = argptr + 1;
		for ( opt_index = 0 ; opt_index < size_options_list ; ++opt_index ) {
			if ( strcmp(option_functions[opt_index].opt_name,option_name) == 0 ) {
				break;
			} /* IF a match */
		} /* FOR */
		if ( opt_index >= size_options_list ) {
			fprintf(stderr,"Unknown option '%s'\n",argptr);
			errors = 1;
			continue;
		} /* IF */
		if ( EQ(option_name,"levels") ) {
			argptr = argv[++argnum];
			if ( argptr == NULL ) {
				missing_option("levels");
			} /* IF */
			else {
				if ( sscanf(argptr,"%d",&max_dir_level) != 1 ||
								max_dir_level < 0 ) {
					errors = 1;
					bad_option("levels",argptr);
				} /* IF */
			} /* ELSE */
		} else if ( EQ(option_name,"skipdir") ) {
			argptr = argv[++argnum];
			if ( argptr == NULL ) {
				missing_option("skipdir");
				errors = 1;
			} /* IF */
			else {
				strcpy(skip_dir_pattern,argptr);
				errcode = regcomp(&skip_dir_expression, skip_dir_pattern,
										REG_ICASE | REG_EXTENDED);
				if ( errcode != 0 ) {
					regerror(errcode,&skip_dir_expression,errmsg,sizeof(errmsg));
					die(1,"Bad skipdir pattern : %s\n",errmsg);
				} /* IF */
			} /* ELSE */
		} else if ( EQ(option_name,"symlink") ) {
			follow_dir_symlink = 1;
		} else if ( EQ(option_name,"help") ) {
			help_only = 1;
			display_usage();
		} else if ( EQ(option_name,"debug") ) {
			debug_mode = 1;
		} else if ( EQ(option_name,"double") ) {
			double_spacing = 1;
		} else if ( EQ(option_name,"noerr") ) {
			no_errors = 1;
		} else if ( EQ(option_name,"user") || EQ(option_name,"notuser") ) {
			argptr = argv[++argnum];
			if ( argptr == NULL ) {
				missing_option("user/notuser");
				errors = 1;
			} /* IF */
			else {
				opt_number = get_userid(argptr);
				if ( opt_number < 0 ) {
					bad_option("user/notuser",argptr);
					errors = 1;
				} /* IF */
				else {
					option = save_numeric_option(opt_index,opt_number,0);
				} /* ELSE */
			} /* ELSE */
		} else if ( EQ(option_name,"perm") || EQ(option_name,"permmask") ||
						EQ(option_name,"addperm") || EQ(option_name,"delperm") ||
						EQ(option_name,"chmod") || EQ(option_name,"notpermmask") ) {
			argptr = argv[++argnum];
			errors |= parse_numeric_option(option_name,opt_index,argptr,
							"%o",&number);
			option = save_numeric_option(opt_index,number,0);
		} else if ( EQ(option_name,"type") ) {
			argptr = argv[++argnum];
			if ( argptr == NULL ) {
				missing_option("type");
				errors = 1;
			} /* IF */
			else {
				if ( strlen(argptr) != 1 || strchr(file_types,*argptr) == NULL ) {
					bad_option("type",argptr);
					errors = 1;
				} /* IF */
				else {
					option = save_string_option(OPT_TYPE,argptr);
				} /* ELSE */
			} /* ELSE */
		} else if ( EQ(option_name,"tar") ) {
			argptr = argv[++argnum];
			if ( argptr == NULL ) {
				missing_option("tar");
				errors = 1;
			} /* IF */
			else {
				option = save_string_option(OPT_TAR,argptr);
			} /* ELSE */
		} else if ( EQ(option_name,"copy") ) {
			argptr = argv[++argnum];
			if ( argptr == NULL ) {
				missing_option("copy");
				errors = 1;
			} /* IF */
			else {
				if ( isdir(argptr) ) {
					option = save_string_option(OPT_COPY,argptr);
				} /* IF */
				else {
					fprintf(stderr,"\"%s\" is not a directory\n",argptr);
					bad_option("copy",argptr);
					errors = 1;
				} /* ELSE */
			} /* ELSE */
		} else if ( EQ(option_name,"links") || EQ(option_name,"bytes") ||
						EQ(option_name,"blocks") || EQ(option_name,"minsize") ||
						EQ(option_name,"maxsize") || EQ(option_name,"head") ||
						EQ(option_name,"inum") ) {
			argptr = argv[++argnum];
			errors |= parse_numeric_option(option_name,opt_index,argptr,"%d",
								&number);
			option = save_numeric_option(opt_index,number,REG_ICASE);
		} else if ( EQ(option_name,"name") || EQ(option_name,"grep") ||
					EQ(option_name,"lgrep") || EQ(option_name,"hgrep") ||
					EQ(option_name,"exclude") ) {
			argptr = argv[++argnum];
			option = save_pattern_option(opt_index,argptr,0);
		} else if ( EQ(option_name,"igrep") || EQ(option_name,"iname") ) {
			argptr = argv[++argnum];
			option = save_pattern_option(opt_index,argptr,REG_ICASE);
		} else if ( EQ(option_name,"group") ) {
			argptr = argv[++argnum];
			if ( argptr == NULL ) {
				missing_option("group");
				errors = 1;
			} /* IF */
			else {
				opt_number = get_group_id(argptr);
				if ( opt_number < 0 ) {
					bad_option("group",argptr);
					errors = 1;
				} /* IF */
				else {
					option = save_numeric_option(OPT_GROUP,opt_number,0);
				} /* ELSE */
			} /* ELSE */
		} else if ( EQ(option_name,"atime") || EQ(option_name,"ctime") ||
							EQ(option_name,"mtime") ) {
			argptr = argv[++argnum];
			if ( argptr != NULL && *argptr == '+' )
				errors |= parse_numeric_option(option_name,opt_index,option_name,
							"%d",&number);
			else
				errors |= parse_numeric_option(option_name,opt_index,argptr,
							"%d",&number);
			option = save_numeric_option(opt_index,number,0);
			if ( argptr != NULL && *argptr == '+' )
				option->modifier = 1;
			else
				option->modifier = 0;
		} else if ( EQ(option_name,"newer") ) {
			argptr = argv[++argnum];
			option = save_filetime_option(OPT_NEWER,argptr);
		} else if ( EQ(option_name,"print") || EQ(option_name,"delete") ||
					EQ(option_name,"killfile") || EQ(option_name,"ls") ||
					EQ(option_name,"file") || EQ(option_name,"filetype") ||
					EQ(option_name,"wc") || EQ(option_name,"lso") ||
					EQ(option_name,"myfile") || EQ(option_name,"list4") ||
					EQ(option_name,"list8") || EQ(option_name,"readonly") ||
					EQ(option_name,"notmyfile") || EQ(option_name,"lsi") ||
					EQ(option_name,"today") || EQ(option_name,"touch") ||
					EQ(option_name,"vi") || EQ(option_name,"mode") ||
					EQ(option_name,"cat") || EQ(option_name,"num") ||
					EQ(option_name,"yesterday") || EQ(option_name,"run") ||
					EQ(option_name,"gw") ) {
			option = save_noparam_option(opt_index);
			if ( EQ(option_name,"yesterday") ) {
				clock = starting_time - day_seconds;
				time_value = localtime(&clock);
				yesterday.year = time_value->tm_year;
				yesterday.month = time_value->tm_mon;
				yesterday.day = time_value->tm_mday;
			} /* IF */
		} else if ( EQ(option_name,"exec") ) {
			argptr = argv[++argnum];
			if ( argptr == NULL ) {
				missing_option("exec");
				errors = 1;
			} /* IF */
			else
				option = save_string_option(OPT_EXEC,argptr);
		} else {
			errors = 1;
			fprintf(stderr,"Unprocessed option '%s'\n",argptr);
		} /* IF */
		if ( option == NULL && option_functions[opt_index].opt_function != NULL ) {
			errors = 1;
		} /* IF */
	} /* FOR */
	if ( errors )
		Usage();

	return(errors);
} /* end of parse_options */

/*********************************************************************
*
* Function  : process_options
*
* Purpose   : Process all the options for the "current" entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If success Then 1 Else zero
*
* Example   : status = process_options();
*
* Notes     : (none)
*
*********************************************************************/

int process_options()
{
	int		opt_index , (*function)() , status;

	status = 1;
	current_option = options_list;
	for ( opt_index = 0 ; status && opt_index < num_options ; ++opt_index ) {
		function = option_functions[current_option->option_code].opt_function;
		status = (*function)();
		current_option += 1;
	} /* FOR */
	fflush(stdout);  /* flush output generated by options */

	return(status);
} /* end of process_options */

/*********************************************************************
*
* Function  : missing_option
*
* Purpose   : Generate an error message for a missing option.
*
* Inputs    : char *option - option name
*
* Output    : error emssage
*
* Returns   : (nothing)
*
* Example   : missing_option("option");
*
* Notes     : (none)
*
*********************************************************************/

void missing_option(char *option)
{
	fprintf(stderr,"Missing value for option \"%s\"\n",option);
	return;
} /* end of missing_option */

/*********************************************************************
*
* Function  : bad_option
*
* Purpose   : Generate an error message for a bad option value.
*
* Inputs    : char *option - option name
*             char *value - option value
*
* Output    : error emssage
*
* Returns   : (nothing)
*
* Example   : missing_option("option",value);
*
* Notes     : (none)
*
*********************************************************************/

void bad_option(char *option, char *value)
{
	fprintf(stderr,"Invalid value \"%s\" specified for option \"%s\"\n",
						value,option);
	return;
} /* end of bad_option */

/*********************************************************************
*
* Function  : get_userid
*
* Purpose   : Get the numeric id corresponding to a username.
*
* Inputs    : char *username - username
*
* Output    : (none)
*
* Returns   : If username located Then userid Else -1
*
* Example   : uid = get_userid(username);
*
* Notes     : (none)
*
*********************************************************************/

int get_userid(char *username)
{
	struct passwd	*user_defn;
	int		userid;

	setpwent();	/* open the password file */
	user_defn = getpwnam(username);
	userid = (user_defn != NULL) ? user_defn->pw_uid : -1;
	endpwent();	/* close the password file */
	return(userid);
} /* end of get_userid */

/*********************************************************************
*
* Function  : get_groupid
*
* Purpose   : Get the numeric id corresponding to a groupname.
*
* Inputs    : char *groupname - groupname
*
* Output    : (none)
*
* Returns   : If groupname located Then groupid Else -1
*
* Example   : uid = get_group_id(groupname);
*
* Notes     : (none)
*
*********************************************************************/

int get_group_id(char *groupname)
{
	struct group	*group_defn;
	int		group_id;

	setgrent();	/* open the groups file */
	group_defn = getgrnam(groupname);
	group_id = (group_defn != NULL) ? group_defn->gr_gid : -1;
	endgrent();	/* close the groups file */
	return(group_id);
} /* end of get_group_id */

/*********************************************************************
*
* Function  : compare_option
*
* Purpose   : Perform a compare operation for the current entry.
*
* Inputs    : OPTION_FUNCTION *opt1_ptr
*             OPTION_FUNCTION *opt2_ptr
*
* Output    : (none)
*
* Returns   : result from strcmp()
*
* Example   : status = compare_option(&opt1,&opt2);
*
* Notes     : (none)
*
*********************************************************************/

int compare_option(OPTION_FUNCTION *opt1_ptr, OPTION_FUNCTION *opt2_ptr)
{
	return( strcmp(opt1_ptr->opt_name,opt2_ptr->opt_name) );
} /* end of compare_option */

/*********************************************************************
*
* Function  : Usage
*
* Purpose   : Display a message indicating proper program parameters.
*
* Inputs    : (none)
*
* Output    : usage message
*
* Returns   : (nothing)
*
* Example   : Usage();
*
* Notes     : (none)
*
*********************************************************************/

void Usage()
{
	int		opt , count , maxlen , length , num_cols;
	OPTION_FUNCTION	*option;

	printf("\nUsage : %s dirname option [... option]\n",progname);
	printf("\nThe %d valid options are :\n",size_options_list);
	qsort((void *)&option_functions,size_options_list,sizeof(OPTION_FUNCTION),compare_option);
	count = 0;
	option = option_functions;
	maxlen = 0;
	for ( opt = 0 ; opt < size_options_list ; ++opt , ++option ) {
		length = strlen(option->opt_name);
		if ( length > maxlen )
			maxlen = length;
	} /* FOR */
	maxlen += 1;
	if ( tty_num_cols < 60 ) {
		tty_num_cols = 60;
	} /* IF */
	num_cols = tty_num_cols / (maxlen + 1);

	count = 0;
	option = option_functions;
	for ( opt = 0 ; opt < size_options_list ; ++opt , ++option ) {
		count += 1;
		if ( count > num_cols ) {
			printf("\n");
			count = 1;
		}
		printf("-%-*s",maxlen,option->opt_name);
	} /* FOR */
	printf("\n");
	return;
} /* end of Usage */

/*********************************************************************
*
* Function  : display_usage
*
* Purpose   : Display a message indicating proper program parameters.
*
* Inputs    : (none)
*
* Output    : usage message
*
* Returns   : (nothing)
*
* Example   : display_usage();
*
* Notes     : (none)
*
*********************************************************************/

int display_usage()
{
	int		opt , count , maxlen;
	OPTION_FUNCTION	*option;

	printf("\nUsage : %s dirname option [... option]\n",progname);
	printf("\nThe %d valid options are :\n",size_options_list);
	qsort((void *)&option_functions,size_options_list,sizeof(OPTION_FUNCTION),compare_option);
	option = option_functions;
	maxlen = 0;
	for ( opt = 0 ; opt < size_options_list ; ++opt , ++option ) {
		count = strlen(option->opt_name);
		if ( count > maxlen )
			maxlen = count;
	} /* FOR */
	option = option_functions;
	for ( opt = 0 ; opt < size_options_list ; ++opt , ++option ) {
		printf("-%-*.*s %s\n",maxlen,maxlen,option->opt_name,
						option->description);
	} /* FOR */
	printf("\n");
	return(0);
} /* end of display_usage */

/*********************************************************************
*
* Function  : parse_numeric_option
*
* Purpose   : Parse a numeric option.
*
* Inputs    : char *optname - option name
*             int opt_code - numeric code corresponding to option name
*             char *optvalue - option value specified by user
*
* Output    : appropriate error messages
*
* Returns   : IF success Then 0 Else 1
*
* Example   : status = parse_numeric_option(optname,OPT_CODE,"value");
*
* Notes     : (none)
*
*********************************************************************/

int parse_numeric_option(char *optname, int opt_code, char *optvalue,
char *format, int *number)
{
	int		errors = 0;

	if ( optvalue == NULL ) {
		missing_option(optname);
		errors = 1;
	} /* IF */
	else {
		if ( sscanf(optvalue,format,number) != 1 ) {
			bad_option(optname,optvalue);
			errors = 1;
		} /* IF */
		else {
		} /* ELSE */
	} /* ELSE */
	return(errors);
} /* end of parse_numeric_option */

/*********************************************************************
*
* Function  : save_numeric_option
*
* Purpose   : Save the specification for a numeric option.
*
* Inputs    : int optcode - option code
*             int number - option value
*             int modifier - modifier
*
* Output    : appropriate error emssage
*
* Returns   : ptr to dynamically allocated structure
*
* Example   : option = save_numeric_option(code,number,modifier);
*
* Notes     : (none)
*
*********************************************************************/

OPTION *save_numeric_option(int optcode, int number, int modifier)
{
	OPTION	*opt;

	if ( num_options >= MAX_NUM_OPTIONS ) {
		die(1,"Exceeded limit of %d options\n",MAX_NUM_OPTIONS);
	} /* IF */
	opt = &options_list[num_options];
	opt->option_code = optcode;
	opt->opt_number = number;
	opt->modifier = modifier;
	num_options += 1;

	return(opt);
} /* end of save_numeric_option */

/*********************************************************************
*
* Function  : save_string_option
*
* Purpose   : Save the specification for a string option.
*
* Inputs    : int optcode - option code
*             char *string - string value
*
* Output    : appropriate error emssage
*
* Returns   : ptr to dynamically allocated structure
*
* Example   : option = save_string_option(code,string);
*
* Notes     : (none)
*
*********************************************************************/

OPTION *save_string_option(int optcode, char *string)
{
	OPTION	*opt;

	if ( num_options >= MAX_NUM_OPTIONS ) {
		die(1,"Exceeded limit of %d options\n",MAX_NUM_OPTIONS);
	} /* IF */
	opt = &options_list[num_options];
	opt->option_code = optcode;
	opt->opt_string = string;
	num_options += 1;

	return(opt);
} /* end of save_string_option */

/*********************************************************************
*
* Function  : save_noparam_option
*
* Purpose   : Save the specification for a "no parameter" option.
*
* Inputs    : int optcode - option code
*
* Output    : appropriate error emssage
*
* Returns   : ptr to dynamically allocated structure
*
* Example   : option = save_noparam_option(code);
*
* Notes     : (none)
*
*********************************************************************/

OPTION *save_noparam_option(int optcode)
{
	OPTION	*opt;

	if ( num_options >= MAX_NUM_OPTIONS ) {
		die(1,"Exceeded limit of %d options\n",MAX_NUM_OPTIONS);
	} /* IF */
	opt = &options_list[num_options];
	opt->option_code = optcode;
	num_options += 1;

	return(opt);
} /* end of save_noparam_option */

/*********************************************************************
*
* Function  : save_filetime_option
*
* Purpose   : Save the specification for a "file time" option.
*
* Inputs    : int optcode - option code
*             char *filename - filename
*
* Output    : appropriate error emssage
*
* Returns   : ptr to dynamically allocated structure
*
* Example   : option = save_filetime_option(code,filename);
*
* Notes     : (none)
*
*********************************************************************/

OPTION *save_filetime_option(int optcode, char *filename)
{
	OPTION	*opt;
	struct stat		filestats;

	if ( num_options >= MAX_NUM_OPTIONS ) {
		die(1,"Exceeded limit of %d options\n",MAX_NUM_OPTIONS);
	} /* IF */
	if ( lstat(filename,&filestats) < 0 ) {
		bad_syscall("lstat failed for \"%s\"",filename);
		opt = NULL;
	} /* IF */
	else {
		opt = &options_list[num_options];
		opt->option_code = optcode;
		num_options += 1;
		opt->opt_number = filestats.st_mtime;
	} /* ELSE */

	return(opt);
} /* end of save_filetime_option */

/*********************************************************************
*
* Function  : print_filename
*
* Purpose   : Print the name of the current entry.
*
* Inputs    : (none)
*
* Output    : name of current entry
*
* Returns   : 1
*
* Example   : status = print_filename();
*
* Notes     : (none)
*
*********************************************************************/

int print_filename()
{
	if ( entry_pathname[0] == '.' && entry_pathname[1] == '/' )
		printf("%s",&entry_pathname[2]);
	else
		printf("%s",entry_pathname);
	if ( entry_filetype == 'l' ) {
		printf(" --> %s",entry_resolved_linkpath);
	} /* IF a symbolic link */
	printf("\n");
	if ( double_spacing ) {
		printf("\n");
	} /* IF */
	fflush(stdout);
	return(1);
} /* end of print_filename */

/*********************************************************************
*
* Function  : save_pattern_option
*
* Purpose   : Save the specification for a pattern option.
*
* Inputs    : int optcode - option code
*             char *pattern - pattern
*             int flags - flags for pattern comparison
*
* Output    : appropriate error emssage
*
* Returns   : ptr to dynamically allocated structure
*
* Example   : option = save_pattern_option(code,pattern,flags);
*
* Notes     : (none)
*
*********************************************************************/

OPTION *save_pattern_option(int optcode, char *pattern, int flags)
{
	OPTION	*opt;
	int		errcode;
	char	errmsg[256];

	if ( num_options >= MAX_NUM_OPTIONS ) {
		die(1,"Exceeded limit of %d options\n",MAX_NUM_OPTIONS);
	} /* IF */
	opt = &options_list[num_options];
	opt->option_code = optcode;
	num_options += 1;
	errcode = regcomp(&opt->expression, pattern, REG_EXTENDED|flags);
	if ( errcode != 0 ) {
		regerror(errcode,&opt->expression,errmsg,sizeof(errmsg));
		die(1,"Bad pattern : %s\n",errmsg);
	} /* IF */

	return(opt);
} /* end of save_pattern_option */

/*********************************************************************
*
* Function  : check_file_name
*
* Purpose   : Perform a regular expression test against the current entry.
*
* Inputs    : (none)
*
* Output    : appropriate error message
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_name();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_name()
{
	int		status , errcode;
	char	errmsg[256];

	errcode = regexec(&current_option->expression,entry_name,0,NULL,0);
	if ( errcode == 0 ) {
		status = 1;
	} /* IF */
	else {
		status = 0;
		if ( errcode != REG_NOMATCH ) {
			regerror(errcode,&current_option->expression,errmsg,sizeof(errmsg));
		} /* IF */
	} /* ELSE */

	return(status);
} /* end of check_file_name */

/*********************************************************************
*
* Function  : check_file_perms
*
* Purpose   : Perform a file pernmissions test against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_perms();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_perms()
{
	return( (entry_stats.st_mode&0777) == current_option->opt_number );
} /* end of check_file_perms */

/*********************************************************************
*
* Function  : check_file_perm_mask
*
* Purpose   : Perform a file permissions mask test against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_perm_mask();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_perm_mask()
{
	return( (entry_stats.st_mode&0777) & current_option->opt_number );
} /* end of check_file_perm_mask */

/*********************************************************************
*
* Function  : check_file_not_perm_mask
*
* Purpose   : Perform a file permissions mask test against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_not_perm_mask();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_not_perm_mask()
{
	return( ! check_file_perm_mask() );
} /* end of check_file_not_perm_mask */

/*********************************************************************
*
* Function  : add_file_perm_mask
*
* Purpose   : Modify the permissions bits for the currenty entry.
*
* Inputs    : (none)
*
* Output    : appropriate error emssage
*
* Returns   : 1
*
* Example   : add_file_perm_mask();
*
* Notes     : (none)
*
*********************************************************************/

int add_file_perm_mask()
{
	int		new_perms;

	new_perms = (entry_stats.st_mode&0777) | current_option->opt_number;
	if ( chmod(entry_pathname,new_perms) < 0 ) {
		bad_syscall("chmod(%s,0%o) failed",entry_pathname,new_perms);
	} /* IF */
	else {
		entry_stats.st_mode &= ~0777;
		entry_stats.st_mode |= new_perms;
	} /* ELSE */

	return(1);
} /* end of add_file_perm_mask */

/*********************************************************************
*
* Function  : delete_file_perm_mask
*
* Purpose   : Modify the permissions bits for the currenty entry.
*
* Inputs    : (none)
*
* Output    : appropriate error emssage
*
* Returns   : 1
*
* Example   : delete_file_perm_mask();
*
* Notes     : (none)
*
*********************************************************************/

int delete_file_perm_mask()
{
	int		new_perms;

	new_perms = (entry_stats.st_mode&0777) & ~current_option->opt_number;
	if ( chmod(entry_pathname,new_perms) < 0 ) {
		bad_syscall("chmod(%s,0%o) failed",entry_pathname,new_perms);
	} /* IF */
	else {
		entry_stats.st_mode &= ~0777;
		entry_stats.st_mode |= new_perms;
	} /* ELSE */

	return(1);
} /* end of delete_file_perm_mask */

/*********************************************************************
*
* Function  : perform_chmod
*
* Purpose   : Modify the permissions bits for the currenty entry.
*
* Inputs    : (none)
*
* Output    : appropriate error emssage
*
* Returns   : 1
*
* Example   : perform_chmod();
*
* Notes     : (none)
*
*********************************************************************/

int perform_chmod()
{
	if ( chmod(entry_pathname,current_option->opt_number) < 0 ) {
		bad_syscall("chmod(%s,0%o) failed",entry_pathname,current_option->opt_number);
	} /* IF */
	else {
		entry_stats.st_mode &= ~0777;
		entry_stats.st_mode |= current_option->opt_number;
	} /* ELSE */

	return(1);
} /* end of perform_chmod */

/*********************************************************************
*
* Function  : check_file_type
*
* Purpose   : Perform a file type check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_type();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_type()
{
	return(current_option->opt_string[0] == entry_filetype);
} /* end of check_file_type */

/*********************************************************************
*
* Function  : check_file_links
*
* Purpose   : Perform a file links check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_links();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_links()
{
	return( current_option->opt_number == entry_stats.st_nlink );
} /* end of check_file_links */

/*********************************************************************
*
* Function  : check_file_owner
*
* Purpose   : Perform a file ownership check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_owner();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_owner()
{
	return( current_option->opt_number == entry_stats.st_uid );
} /* end of check_file_owner */

/*********************************************************************
*
* Function  : check_myfile
*
* Purpose   : Test to see if the user owns the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_myfile();
*
* Notes     : (none)
*
*********************************************************************/

int check_myfile()
{
	return( my_uid == entry_stats.st_uid );
} /* end of check_myfile */

/*********************************************************************
*
* Function  : check_notmyfile
*
* Purpose   : Test to see if the user does not own the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_notmyfile();
*
* Notes     : (none)
*
*********************************************************************/

int check_notmyfile()
{
	return( my_uid != entry_stats.st_uid );
} /* end of check_notmyfile */

/*********************************************************************
*
* Function  : check_file_not_owner
*
* Purpose   : Test to see if the current entry is not owned by the
*             specified user
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_not_owner();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_not_owner()
{
	return( current_option->opt_number != entry_stats.st_uid );
} /* end of check_file_not_owner */

/*********************************************************************
*
* Function  : check_file_group
*
* Purpose   : Perform a file group check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_group();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_group()
{
	return( current_option->opt_number == entry_stats.st_gid );
} /* end of check_file_group */

/*********************************************************************
*
* Function  : check_file_blocks
*
* Purpose   : Perform a file blocks check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_blocks();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_blocks()
{
	return( current_option->opt_number == ( (entry_stats.st_size+511) >> 9) );
} /* end of check_file_blocks */

/*********************************************************************
*
* Function  : check_file_bytes
*
* Purpose   : Perform a file bytes check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_bytes();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_bytes()
{
	int		status;

	status = current_option->opt_number == entry_stats.st_size;
	return( status );
} /* end of check_file_bytes */

/*********************************************************************
*
* Function  : check_file_minsize
*
* Purpose   : Perform a file minsize check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_minsize();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_minsize()
{
	int		status;

	status = current_option->opt_number <= entry_stats.st_size;
	return( status );
} /* end of check_file_minsize */

/*********************************************************************
*
* Function  : check_file_maxsize
*
* Purpose   : Perform a file maxsize check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_maxsize();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_maxsize()
{
	int		status;

	status = current_option->opt_number >= entry_stats.st_size;
	return( status );
} /* end of check_file_maxsize */

/*********************************************************************
*
* Function  : check_file_atime
*
* Purpose   : Perform a file access-time check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_atime();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_atime()
{
	int		status;

	status = check_time(entry_stats.st_atime);
	return( status );
} /* end of check_file_atime */

/*********************************************************************
*
* Function  : check_file_mtime
*
* Purpose   : Perform a file modified-time check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_mtime();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_mtime()
{
	int		status;
	char	*buffer;

	buffer = ctime(&entry_stats.st_mtime);
	debug_print("check_file_mtime(%s) - entry_stats.st_mtime = %s",entry_pathname,
					buffer);
	status = check_time(entry_stats.st_mtime);
	return( status );
} /* end of check_file_mtime */

/*********************************************************************
*
* Function  : check_time
*
* Purpose   : Perform a file time check against the current entry.
*
* Inputs    : time_t time_value - time value for comparison
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_time(time_value);
*
* Notes     : (none)
*
*********************************************************************/

int check_time(time_t time_value)
{
	int		status , num_days;
	char	buffer[100];

	num_days = (int)(starting_time - time_value);
	num_days = num_days / DAY_SECONDS;
	status = current_option->modifier ? num_days >= current_option->opt_number :
					num_days < current_option->opt_number;
	strcpy(buffer,ctime(&time_value));
	buffer[strlen(buffer)-1] = '\0';  /* kill trailing newline */
	debug_print("check_time(%s) = %d , %d\n",buffer,status,num_days);
	return(status);
} /* end of check_time */

/*********************************************************************
*
* Function  : check_file_ctime
*
* Purpose   : Perform a file created-time check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_ctime();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_ctime()
{
	int		status;

	status = check_time(entry_stats.st_ctime);
	return( status );
} /* end of check_file_ctime */

/*********************************************************************
*
* Function  : check_file_newer
*
* Purpose   : Perform a file newer check against the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_file_newer();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_newer()
{
	return( current_option->opt_number < entry_stats.st_mtime );
} /* end of check_file_newer */

/*********************************************************************
*
* Function  : delete_file
*
* Purpose   : Delete the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If success Then 1 Else 0
*
* Example   : status = delete_file();
*
* Notes     : The user is prompted for verification.
*
*********************************************************************/

int delete_file()
{
	int		status;
	char	prompt[1024] , buffer[100] , reply[100];

	sprintf(prompt,"Delete %s (y/n) ? ",entry_pathname);
	printf("%s",prompt);
	fflush(stdout);
	fgets(buffer,sizeof(buffer),stdin);
	while ( sscanf(buffer,"%s",reply) != 1 ) {
		printf("%s",prompt);
		fflush(stdout);
		fgets(buffer,sizeof(buffer),stdin);
	} /* WHILE */
	if ( strlen(reply) == 1 && (reply[0] == 'y' || reply[0] == 'Y') ) {
		if ( unlink(entry_pathname) < 0 ) {
			bad_syscall("Can't delete file \"%s\"",entry_pathname);
			status = 0;
		} /* IF */
		else
			status = 1;
	} /* IF */
	else
		status = 1;
	return(status);
} /* end of delete_file */

/*********************************************************************
*
* Function  : kill_file
*
* Purpose   : Delete the current entry.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If success Then 1 Else 0
*
* Example   : status = kill_file();
*
* Notes     : The user is NOT prompted for verification.
*
*********************************************************************/

int kill_file()
{
	int		status;

	if ( unlink(entry_pathname) < 0 ) {
		bad_syscall("Can't delete file \"%s\"",entry_pathname);
		status = 0;
	} /* IF */
	else
		status = 1;
	return(status);
} /* end of kill_file */

/*********************************************************************
*
* Function  : perform_ls
*
* Purpose   : Perform the equivalent of "ls -l".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_ls();
*
* Notes     : (none)
*
*********************************************************************/

int perform_ls()
{
	list_file_attr(entry_pathname,&entry_stats,1,0);
	if ( double_spacing ) {
		printf("\n");
	} /* IF */
	return(1);
} /* end of perform_ls */

/*********************************************************************
*
* Function  : perform_lso
*
* Purpose   : Perform the equivalent of "ls -lo".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_lso();
*
* Notes     : (none)
*
*********************************************************************/

int perform_lso()
{
	list_file_attr(entry_pathname,&entry_stats,0,0);
	if ( double_spacing ) {
		printf("\n");
	} /* IF */
	return(1);
} /* end of perform_lso */

/*********************************************************************
*
* Function  : perform_lsi
*
* Purpose   : Perform the equivalent of "ls -li".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_lsi();
*
* Notes     : (none)
*
*********************************************************************/

int perform_lsi()
{
	list_file_attr(entry_pathname,&entry_stats,1,1);
	if ( double_spacing ) {
		printf("\n");
	} /* IF */
	return(1);
} /* end of perform_lsi */

/*********************************************************************
*
* Function  : perform_file
*
* Purpose   : Perform a "file".
*
* Inputs    : (none)
*
* Output    : output from "file" command
*
* Returns   : 1
*
* Example   : status = perform_file();
*
* Notes     : (none)
*
*********************************************************************/

int perform_file()
{
	char	command[BUFSIZ];

	sprintf(command,"file %s",entry_pathname);
	system(command);
	return(1);
} /* end of perform_file */

/*********************************************************************
*
* Function  : perform_exec
*
* Purpose   : Perform an "exec" command.
*
* Inputs    : (none)
*
* Output    : any output from specified command
*
* Returns   : 1
*
* Example   : status = perform_exec();
*
* Notes     : (none)
*
*********************************************************************/

int perform_exec()
{
	char	command[BUFSIZ] , *ptr , *cmd_ptr;
	int		cmd_len;

	cmd_len = 0;
	cmd_ptr = command;
	ptr = current_option->opt_string;
	while ( *ptr != '\0' ) {
		if ( *ptr == '{' && ptr[1] == '}' ) {
			strcpy(cmd_ptr,entry_pathname);
			ptr += 2;
			cmd_ptr += strlen(entry_pathname);
			cmd_len += strlen(entry_pathname);
		} /* IF */
		else {
			*cmd_ptr = *ptr;
			cmd_ptr += 1;
			cmd_len += 1;
			ptr += 1;
		} /* ELSE */
	} /* WHILE */
	*cmd_ptr = '\0';
	system(command);

	return(1);
} /* end of perform_exec */

/*********************************************************************
*
* Function  : perform_grep
*
* Purpose   : Perform the equivalent of "grep".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_grep();
*
* Notes     : (none)
*
*********************************************************************/

int perform_grep()
{
	FILE	*input;
	char	buffer[BUFSIZ] , errmsg[256];
	int		status = 0 , recnum = 0 , errcode;

	input = fopen(entry_pathname,"r");
	if ( input == NULL )
		bad_syscall("Can't open file \"%s\"",entry_pathname);
	else {
		while ( fgets(buffer,sizeof(buffer),input) != NULL ) {
			recnum += 1;

			errcode = regexec(&current_option->expression,buffer,0,NULL,0);
			if ( errcode == 0 ) {
				printf("%s:%d\t%s",entry_pathname,recnum,buffer);
				fflush(stdout);
				status = 1;
			} /* IF pattern found in record buffer */
			else {
				if ( errcode != REG_NOMATCH ) {
					regerror(errcode,&current_option->expression,errmsg,sizeof(errmsg));
				} /* IF */
			} /* ELSE */

		} /* WHILE over data file records */
		fclose(input);
	} /* ELSE */

	return( status );
} /* end of perform_grep */

/*********************************************************************
*
* Function  : display_text
*
* Purpose   : Display a line of text containing a match. The occurrences
*             of the macthes will be highlited.
*
* Inputs    : regmatch_t *pmatch - regular expression result
*             char *ptr1 - record buffer pointer
*             int  recnum - record number
*
* Output    : (none)
*
* Returns   : pointer to compiled regular expression
*
* Example   : regexp = display_text("data[0-9]");
*
* Notes     : (none)
*
*********************************************************************/

void display_text(regmatch_t *pmatch, char *ptr1, int recnum)
{
	int		errcode , length , count;
	char	temp_buffer[1024];

	errcode = 0;
	printf("%s:%d:\t",entry_pathname,recnum);
	while ( errcode == 0 ) {
	/* First print the "chunk" extending from ptr1 to the byte
	   just before the 1st matched byte. Must check to see if
	   the match started at the beginning of the current buffer
	   pointer.
	*/
		if ( pmatch[0].rm_so > 0 ) {
			length = pmatch[0].rm_so;
			strncpy(temp_buffer,ptr1,length);
			temp_buffer[length] = '\0';
			printf("%s",temp_buffer);
		} /* IF */

		/* Highlite the matching string */
		length = pmatch[0].rm_eo - pmatch[0].rm_so;
		strncpy(temp_buffer,&ptr1[pmatch[0].rm_so],length);
		temp_buffer[length] = '\0';
		standout_mode();
		printf("%s",temp_buffer);
		end_standout_mode();

		/* Search for the next match in the current record */
		ptr1 = &ptr1[pmatch[0].rm_eo];
/*****	errcode = regexec(pattern, ptr1, (size_t)1, pmatch, 0); *****/
		errcode = REG_NOMATCH;
		errcode = regexec(&current_option->expression, ptr1, (size_t)1, pmatch, 0);
	} /* WHILE loop finding matches in record */
	/* Print remaining unmatched portion of record */
	printf("%s\n",ptr1);
} /* end of display_text */

/*********************************************************************
*
* Function  : perform_hgrep
*
* Purpose   : Perform the equivalent of "grep".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_hgrep();
*
* Notes     : (none)
*
*********************************************************************/

int perform_hgrep()
{
	FILE	*input;
	char	buffer[BUFSIZ] , errmsg[256];
	int		length , status = 0 , recnum = 0 , errcode;
	regmatch_t  pmatch[2];

	input = fopen(entry_pathname,"r");
	if ( input == NULL )
		bad_syscall("Can't open file \"%s\"",entry_pathname);
	else {
		while ( fgets(buffer,sizeof(buffer),input) != NULL ) {
			recnum += 1;
			length = strlen(buffer);
			buffer[--length] = '\0';  /* kill newline */

			errcode = regexec(&current_option->expression,buffer,(size_t)1,pmatch,0);
			if ( errcode == 0 ) {
				display_text(pmatch,buffer,recnum);
				/* printf("%s:%d\t%s",entry_pathname,recnum,buffer); */
				fflush(stdout);
				status = 1;
			} /* IF pattern found in record buffer */
			else {
				if ( errcode != REG_NOMATCH ) {
					regerror(errcode,&current_option->expression,errmsg,sizeof(errmsg));
				} /* IF */
			} /* ELSE */

		} /* WHILE over data file records */
		fclose(input);
	} /* ELSE */

	return( status );
} /* end of perform_hgrep */

/*********************************************************************
*
* Function  : perform_igrep
*
* Purpose   : Perform the equivalent of "grep -i".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_igrep();
*
* Notes     : (none)
*
*********************************************************************/

int perform_igrep()
{
	FILE	*input;
	char	buffer[BUFSIZ] , errmsg[256];
	int		status = 0 , recnum = 0 , errcode;

	input = fopen(entry_pathname,"r");
	if ( input == NULL ) {
		bad_syscall("Can't open file \"%s\"",entry_pathname);
	} /* IF */
	else {
		while ( fgets(buffer,sizeof(buffer),input) != NULL ) {
			recnum += 1;
			errcode = regexec(&current_option->expression,buffer,0,NULL,0);
			if ( errcode == 0 ) {
				printf("%s:%d\t%s",entry_pathname,recnum,buffer);
				fflush(stdout);
				status = 1;
			} /* IF pattern found in buffer */
			else {
				if ( errcode != REG_NOMATCH ) {
					regerror(errcode,&current_option->expression,
									errmsg,sizeof(errmsg));
				} /* IF error during match */
			} /* ELSE no match */
		} /* WHILE over data file records */
		fclose(input);
	} /* ELSE open succeeded */

	return( status );
} /* end of perform_igrep */

/*********************************************************************
*
* Function  : perform_wc
*
* Purpose   : Perform the equivalent of "wc -l".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_wc();
*
* Notes     : (none)
*
*********************************************************************/

int perform_wc()
{
	FILE	*input;
	char	buffer[BUFSIZ];
	int		num_chars = 0 , recnum = 0;

	input = fopen(entry_pathname,"r");
	if ( input == NULL )
		bad_syscall("Can't open file \"%s\"",entry_pathname);
	else {
		for ( ; fgets(buffer,sizeof(buffer),input) != NULL ; ++recnum ) {
			num_chars += strlen(buffer);
		} /* FOR over data file records */
		fclose(input);
		printf("%7d %7d %s\n",recnum,num_chars,entry_pathname);
		fflush(stdout);
	} /* ELSE */

	return( 1 );
} /* end of perform_wc */

/*********************************************************************
*
* Function  : perform_head
*
* Purpose   : Perform the equivalent of "Head" command.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_head();
*
* Notes     : (none)
*
*********************************************************************/

int perform_head()
{
	FILE	*input;
	char	buffer[BUFSIZ];
	int		num_chars = 0 , recnum = 0 , head_size;

	input = fopen(entry_pathname,"r");
	if ( input == NULL )
		bad_syscall("Can't open file \"%s\"",entry_pathname);
	else {
		head_size = current_option->opt_number;
		while ( fgets(buffer,sizeof(buffer),input) != NULL ) {
			if ( ++recnum > head_size )
				break;
			printf("%5d\t%s",recnum,buffer);
		} /* WHILE over data file records */
		fclose(input);
		fflush(stdout);
	} /* ELSE */

	return( 1 );
} /* end of perform_head */

/*********************************************************************
*
* Function  : list_file
*
* Purpose   : Perform the equivalent of "cat -n".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = list_file();
*
* Notes     : (none)
*
*********************************************************************/

int list_file(char *filename, int tabstop)
{
	FILE	*input;
	char	recbuff[BUFSIZ] , new_recbuff[sizeof(recbuff)];
	int		recnum;

	input = fopen(filename,"r");
	if ( input == NULL )
		bad_syscall("Can't open file \"%s\"",filename);
	else {
		printf("\n=== %s   ===\n",filename);
		for ( recnum = 0 ; fgets(recbuff,sizeof(recbuff),input) != NULL ; ++recnum ) {
			recbuff[strlen(recbuff)-1] = '\0'; /* remove trailing newline */
			expand_tabs(new_recbuff,recbuff, tabstop);
			printf("%5d\t%s\n",recnum,new_recbuff);
		} /* WHILE over data file records */
		fclose(input);
		fflush(stdout);
	} /* ELSE */

	return(0);
} /* end of list_file */

/*********************************************************************
*
* Function  : list4_file
*
* Purpose   : Perform the equivalent of "expand -4 | cat -n".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = list4_file();
*
* Notes     : (none)
*
*********************************************************************/

int list4_file()
{
	return( list_file(entry_pathname,4) );
} /* end of list4_file */

/*********************************************************************
*
* Function  : list8_file
*
* Purpose   : Perform the equivalent of "expand -8 | cat -n".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = list8_file();
*
* Notes     : (none)
*
*********************************************************************/

int list8_file()
{
	return( list_file(entry_pathname,8) );
} /* end of list8_file */

/*********************************************************************
*
* Function  : perform_lgrep
*
* Purpose   : Perform the equivalent of "grep -l".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_lgrep();
*
* Notes     : (none)
*
*********************************************************************/

int perform_lgrep()
{
	FILE	*input;
	char	buffer[BUFSIZ] , errmsg[256];
	int		status = 0 , errcode;

	input = fopen(entry_pathname,"r");
	if ( input == NULL )
		bad_syscall("Can't open file \"%s\"",entry_pathname);
	else {
		while ( status == 0 && fgets(buffer,sizeof(buffer),input) != NULL ) {
			errcode = regexec(&current_option->expression,buffer,0,NULL,0);
			if ( errcode == 0 ) {
				status = 1;
				printf("%s\n",entry_pathname);
				fflush(stdout);
			} /* IF pattern found in buffer */
			else {
				regerror(errcode,&current_option->expression,
								errmsg,sizeof(errmsg));
			} /* ELSE */
		} /* WHILE over data file records */
		fclose(input);
	} /* ELSE */

	return( status );
} /* end of perform_lgrep */

/*********************************************************************
*
* Function  : check_read_only
*
* Purpose   : Check to see if the file is read only.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = check_read_only();
*
* Notes     : (none)
*
*********************************************************************/

int check_read_only()
{
	return( access(entry_pathname , W_OK) != 0 );
} /* end of check_read_only */

/*********************************************************************
*
* Function  : check_file_today
*
* Purpose   : Check to see if the file was modified today.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = check_file_today();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_today()
{
	struct tm	*file , *now;
	time_t		clock;
	int			file_day , today;

	file = localtime(&entry_stats.st_mtime);
	file_day = file->tm_yday;
	clock = time(NULL);
	now = localtime(&clock);
	today = now->tm_yday;

	return( file_day == today );
} /* end of check_file_today */

/*********************************************************************
*
* Function  : perform_touch
*
* Purpose   : Perform the equivalent of "touch".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_touch();
*
* Notes     : (none)
*
*********************************************************************/

int perform_touch()
{
	struct utimbuf	dest_times;

	dest_times.modtime = time(NULL);
	dest_times.actime = entry_stats.st_atime;
	if ( utime(entry_pathname,&dest_times) < 0 ) {
		bad_syscall("utimes failed for \"%s\"",
				entry_pathname);
	} /* IF */
	return(1);
} /* end of perform_touch */

/*********************************************************************
*
* Function  : perform_tar
*
* Purpose   : Perform a "tar uf" command.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_tar();
*
* Notes     : (none)
*
*********************************************************************/

int perform_tar()
{
	char	command[2048];

	sprintf(command,"tar uf %s %s",current_option->opt_string,entry_pathname);
	system(command);
	return(1);
} /* end of perform_tar */

/*********************************************************************
*
* Function  : perform_vi
*
* Purpose   : Perform "vi".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_vi();
*
* Notes     : (none)
*
*********************************************************************/

int perform_vi()
{
	char	command[2048];

	printf("run vi on %s : ",entry_pathname);
	fflush(stdout);
	fgets(command,100,stdin);
	sprintf(command,"vi %s",entry_pathname);
	system(command);

	return(1);
} /* end of perform_vi */

/*********************************************************************
*
* Function  : perform_mode
*
* Purpose   : Print out the file's mode bits.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_mode();
*
* Notes     : (none)
*
*********************************************************************/

int perform_mode()
{
	printf("0%o %s\n",entry_stats.st_mode,entry_pathname);
	fflush(stdout);
	return 1;
} /* end of perform_mode */

/*********************************************************************
*
* Function  : perform_cat
*
* Purpose   : Perform the equivalent of "cat".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_cat();
*
* Notes     : (none)
*
*********************************************************************/

int perform_cat()
{
	FILE	*input;
	char	buffer[BUFSIZ];

	input = fopen(entry_pathname,"r");
	if ( input == NULL )
		bad_syscall("Can't open file \"%s\"",entry_pathname);
	else {
		printf("\n--- %s ---\n",entry_pathname);
		while ( fgets(buffer,sizeof(buffer),input) != NULL ) {
			printf("%s",buffer);
		} /* WHILE over data file records */
		fclose(input);
		printf("\n");
		fflush(stdout);
	} /* ELSE */

	return( 1 );
} /* end of perform_cat */

/*********************************************************************
*
* Function  : perform_num
*
* Purpose   : Perform the equivalent of "cat -n".
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : 1
*
* Example   : status = perform_num();
*
* Notes     : (none)
*
*********************************************************************/

int perform_num()
{
	FILE	*input;
	char	buffer[BUFSIZ];
	int		recnum = 1;

	input = fopen(entry_pathname,"r");
	if ( input == NULL )
		bad_syscall("Can't open file \"%s\"",entry_pathname);
	else {
		printf("\n--- %s ---\n",entry_pathname);
		for ( ; fgets(buffer,sizeof(buffer),input) != NULL ; ++recnum ) {
			printf("%5d\t%s",recnum,buffer);
		} /* FOR over data file records */
		fclose(input);
		printf("\n");
		fflush(stdout);
	} /* ELSE */

	return( 1 );
} /* end of perform_num */

/*********************************************************************
*
* Function  : check_file_yesterday
*
* Purpose   : Check to see if the file was modified yesterday.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If yes Then 1 Else 0
*
* Example   : status = check_file_yesterday();
*
* Notes     : (none)
*
*********************************************************************/

int check_file_yesterday()
{
	struct tm	*file_time;
	int		status;

	file_time = localtime(&entry_stats.st_mtime);
	status = file_time->tm_year == yesterday.year && file_time->tm_mon == yesterday.month &&
				file_time->tm_mday == yesterday.day;

	return( status );
} /* end of check_file_yesterday */

/*********************************************************************
*
* Function  : check_for_exec_perm
*
* Purpose   : Test to see if the file can be run by the user.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If file is runable by the user Then 1 Else 0
*
* Example   : status = check_for_exec_perm();
*
* Notes     : (none)
*
*********************************************************************/

int check_for_exec_perm()
{
	int		status;

	status = access(entry_pathname,X_OK) == 0;
	return(status);
} /* end of check_for_exec_perm */

/*********************************************************************
*
* Function  : copy_file_under_dir
*
* Purpose   : Copy a file under a directory.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If file is runable by the user Then 1 Else 0
*
* Example   : status = copy_file_under_dir();
*
* Notes     : (none)
*
*********************************************************************/

int copy_file_under_dir()
{
	int		status;
	FILE	*input , *output;
	char	dest_file[1024] , *last_slash , buffer[4096];

	status = 0;
	input  = fopen(entry_pathname,"r");
	if ( input == NULL ) {
		bad_syscall("fopen() failed for \"%s\"",entry_pathname);
	} /* IF */
	else {
		last_slash = strrchr(entry_pathname,'/');
		if ( last_slash == NULL )
			last_slash = entry_pathname;
		else
			last_slash += 1;
		sprintf(dest_file,"%s/%s",current_option->opt_string,last_slash);
		output = fopen(dest_file,"w");
		if ( output == NULL ) {
			bad_syscall("fopen() failed for \"%s\"",dest_file);
			fclose(input);
		} /* IF */
		else {
			while ( fgets(buffer , sizeof(buffer) , input) != NULL ) {
				fprintf(output,"%s",buffer);
			} /* WHILE */
			fclose(input);
			fclose(output);
			status = 1;
		} /* ELSE */
	} /* ELSE */

	return(status);
} /* end of copy_file_under_dir */

/*********************************************************************
*
* Function  : check_inode_number
*
* Purpose   : Check for a specific inode number.
*
* Inputs    : (none)
*
* Output    : (none)
*
* Returns   : If a match Then 1 Else 0
*
* Example   : status = check_inode_number();
*
* Notes     : (none)
*
*********************************************************************/

int check_inode_number()
{
	int		status;

	status = current_option->opt_number == entry_stats.st_ino;
	return( status );
} /* end of check_inode_number */

/*********************************************************************
*
* Function  : display_filename_and_type
*
* Purpose   : Print the name and type of the current entry.
*
* Inputs    : (none)
*
* Output    : name of current entry
*
* Returns   : 1
*
* Example   : status = display_filename_and_type();
*
* Notes     : (none)
*
*********************************************************************/

int display_filename_and_type()
{
	printf("[%c] ",entry_filetype);
	if ( entry_pathname[0] == '.' && entry_pathname[1] == '/' )
		printf("%s",&entry_pathname[2]);
	else
		printf("%s",entry_pathname);
	if ( entry_filetype == 'l' ) {
		printf(" --> %s",entry_resolved_linkpath);
	} /* IF a symbolic link */
	printf("\n");
	if ( double_spacing ) {
		printf("\n");
	} /* IF */
	fflush(stdout);
	return(1);
} /* end of display_filename_and_type */

/*********************************************************************
*
* Function  : perform_exclude
*
* Purpose   : Perform a regular expression test against the current entry.
*
* Inputs    : (none)
*
* Output    : appropriate error message
*
* Returns   : If a match Then 0 Else 1
*
* Example   : status = perform_exclude();
*
* Notes     : (none)
*
*********************************************************************/

int perform_exclude()
{
	int		status , errcode;
	char	errmsg[256];

	errcode = regexec(&current_option->expression,entry_name,0,NULL,0);
	if ( errcode == 0 ) {
		status = 0;
	} /* IF */
	else {
		status = 1;
		if ( errcode != REG_NOMATCH ) {
			regerror(errcode,&current_option->expression,errmsg,sizeof(errmsg));
		} /* IF */
	} /* ELSE */

	return(status);
} /* end of perform_exclude */
