/*********************************************************************
*
* File      : bad_syscall.c
*
* Author    : Barry Kimelman
*
* Created   : August 29, 2001
*
* Purpose   : Display an error message for a failed UNIX system call.
*
*********************************************************************/

#include	<stdio.h>
#include	<stdarg.h>
#include	<unistd.h>
#include	<errno.h>

extern	int		no_errors;

/*********************************************************************
*
* Function  : bad_syscall
*
* Purpose   : Dispklay a formatted error emssage for a failed UNIX
*             system call.
*
* Inputs    : variable argument list (ala printf)
*
* Output    : the formatted error emssage
*
* Returns   : (nothing)
*
* Example   : bad_syscall("Can't open file %s",filename);
*
* Notes     : (none)
*
*********************************************************************/

void bad_syscall(char *fmt, ...)
{
	va_list ap;
	int		errnum;

	if ( ! no_errors ) {
		errnum = errno;
		va_start(ap, fmt);
		vfprintf(stderr,fmt,ap);
		fprintf(stderr," : %s\n",strerror(errnum));
		va_end(ap);
		errno = errnum;
	}
	return;
} /* end of bad_syscall */
