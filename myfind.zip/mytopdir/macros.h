#ifndef	MACROS_H_INCL
#define	MACROS_H_INCL	1

#define	NE(s1,s2)	strcmp(s1,s2)
#define	EQ(s1,s2)	(strcmp(s1,s2)==0)

#endif
